
import edu.princeton.cs.algs4.StdIn;

public class Subset {
	public static void main(String[] args) {
		int k = Integer.parseInt(args[0]);
		String s = StdIn.readLine();
		String[] c = s.split(" ");
		RandomizedQueue<String> q = new RandomizedQueue<String>();
		for (String t : c)
			q.enqueue(t);
		for (int i = 0; i < k; i++) {
			q.dequeue();
		}
	}
}
