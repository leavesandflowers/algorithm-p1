import java.util.Comparator;
import java.util.Iterator;

import javax.crypto.SealedObject;

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.Stopwatch;

public class Solver {

	private MinPQ<Node> queues;
	private MinPQ<Node> twinQueues;

	private int moves;

	private MinPQ<Board> result;

	private Board initialBoard;

	private class Node {
		public Board board;
		public Node pre;
		public Integer steps;

		public Node(Board board, Integer steps, Node pre) {
			this.board = board;
			this.steps = steps;
			this.pre = pre;
		}

	}

	public Solver(Board initial) {
		// find a solution to the initial board (using the A* algorithm)
		if (initial == null)
			throw new NullPointerException();
		Stopwatch s = new Stopwatch();
		init();
		this.initialBoard = initial;
		moves = predict(queues, twinQueues);
		StdOut.println(s.elapsedTime());
	}

	private int predict(MinPQ<Node> queues, MinPQ<Node> twinQueues) {
		Node i = new Node(initialBoard, 0, null);
		queues.insert(i);
		Node ti = new Node(initialBoard.twin(), 0, null);
		twinQueues.insert(ti);
		int top = Math.max(initialBoard.manhattan(), initialBoard.twin().manhattan());
		while (queues.min().steps <= 2 * top) {
			if (queues.min().board.isGoal()) {
				Node r = queues.min();
				while (r != null) {
					result.insert(r.board);
					r = r.pre;
				}
				return queues.delMin().steps;
			} else if (twinQueues.min().board.isGoal()) {
				return -1;
			} else {
				processNode(queues, true);
				processNode(twinQueues, false);
			}
		}
		return -1;
	}

	private void processNode(MinPQ<Node> queues, boolean origan) {
		Node search = queues.delMin();
		Board b = search.board;
		Iterator<Board> i = b.neighbors().iterator();
		while (i.hasNext()) {
			boolean duplicate = false;
			Board n = i.next();
			Node t = search;
			while (t != null) {
				if (n.toString().equals(t.board.toString()))
					duplicate = true;
				t = t.pre;
			}
			// StdOut.println("duplicate:" + duplicate);
			if (!duplicate) {
				Node insertNode = new Node(n, search.steps + 1, search);
				queues.insert(insertNode);
			}
		}
		// StdOut.println("step:" + search.steps);
		// StdOut.println("board:" + b.toString());
	}

	public boolean isSolvable() {
		// is the initial board solvable?
		return moves != -1;

	}

	private void init() {
		queues = new MinPQ<Node>(new Comparator<Node>() {

			@Override
			public int compare(Node o1, Node o2) {
				// if (o1.steps == o2.steps) {
				// return o1.board.manhattan() - o2.board.manhattan();
				// } else {
				// return o1.steps - o2.steps;
				// }
				return (o1.steps - o2.steps) + (o1.board.manhattan() - o2.board.manhattan());
			}

		});
		twinQueues = new MinPQ<Node>(new Comparator<Node>() {

			@Override
			public int compare(Node o1, Node o2) {
				// if (o1.steps == o2.steps) {
				// return o1.board.manhattan() - o2.board.manhattan();
				// } else {
				// return o1.steps - o2.steps;
				// }
				return (o1.steps - o2.steps) + (o1.board.manhattan() - o2.board.manhattan());
			}

		});
		result = new MinPQ<Board>(new Comparator<Board>() {

			@Override
			public int compare(Board o1, Board o2) {
				return o2.manhattan() - o1.manhattan();
			}

		});
	}

	public int moves() {
		// min number of moves to solve initial board; -1 if unsolvable
		return moves;

	}

	public Iterable<Board> solution() {
		// sequence of boards in a shortest solution; null if unsolvable
		if (isSolvable())
			return new SolverIterable();
		return null;
	}

	private class SolverIterable implements Iterable<Board> {

		@Override
		public Iterator<Board> iterator() {
			return new Iterator<Board>() {

				@Override
				public boolean hasNext() {
					return !result.isEmpty();
				}

				@Override
				public Board next() {
					return result.delMin();
				}
			};
		}

	}

	public static void main(String[] args) {
		// solve a slider puzzle (given below)
		// create initial board from file
		In in = new In(args[0]);
		int n = in.readInt();
		int[][] blocks = new int[n][n];
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++)
				blocks[i][j] = in.readInt();
		Board initial = new Board(blocks);

		// solve the puzzle
		Solver solver = new Solver(initial);

		// print solution to standard output
		if (!solver.isSolvable())
			StdOut.println("No solution possible");
		else {
			StdOut.println("Minimum number of moves = " + solver.moves());
			for (Board board : solver.solution())
				StdOut.println(board);
		}
	}
}