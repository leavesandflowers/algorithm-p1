import java.util.Comparator;
import java.util.Iterator;

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.StdOut;

public class Solver {

	private MinPQ<Board> queues;
	private MinPQ<Board> result;

	public Solver(Board initial) {
		// find a solution to the initial board (using the A* algorithm)
		if (initial == null)
			throw new NullPointerException();
		queues = new MinPQ<Board>(new Comparator<Board>() {

			@Override
			public int compare(Board o1, Board o2) {
				return o1.hamming() - o2.hamming();
			}

		});
		result = new MinPQ<Board>(new Comparator<Board>() {

			@Override
			public int compare(Board o1, Board o2) {
				return o2.hamming() - o1.hamming();
			}

		});
		queues.insert(initial);
	}

	public boolean isSolvable() {
		// is the initial board solvable?
		return true;
	}

	public int moves() {
		// min number of moves to solve initial board; -1 if unsolvable
		int moves = 0;
		while (!queues.isEmpty() && !queues.min().isGoal()) {
			Board search = queues.delMin();
			Iterator<Board> i = search.neighbors().iterator();
			while (i.hasNext()) {
				Board n = i.next();
				if (!n.toString().equals(search.toString()))
					queues.insert(n);
			}
			result.insert(search);
			moves++;
		}
		StdOut.println(queues.min().manhattan());
		result.insert(queues.delMin());
		return moves;
	}

	public Iterable<Board> solution() {
		// sequence of boards in a shortest solution; null if unsolvable
		return new SolverIterable();
	}

	private class SolverIterable implements Iterable<Board> {

		@Override
		public Iterator<Board> iterator() {
			return new Iterator<Board>() {

				@Override
				public boolean hasNext() {
					return !result.isEmpty();
				}

				@Override
				public Board next() {
					return result.delMin();
				}
			};
		}

	}

	public static void main(String[] args) {
		// solve a slider puzzle (given below)
		// create initial board from file
		In in = new In(args[0]);
		int n = in.readInt();
		int[][] blocks = new int[n][n];
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++)
				blocks[i][j] = in.readInt();
		Board initial = new Board(blocks);

		// solve the puzzle
		Solver solver = new Solver(initial);

		// print solution to standard output
		if (!solver.isSolvable())
			StdOut.println("No solution possible");
		else {
			StdOut.println("Minimum number of moves = " + solver.moves());
			for (Board board : solver.solution())
				StdOut.println(board);
		}
	}
}