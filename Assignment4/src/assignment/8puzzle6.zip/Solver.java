import java.util.Comparator;
import java.util.Iterator;

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.Stopwatch;

public class Solver {

	private MinPQ<Node> queues;
	private MinPQ<Node> twinQueues;

	private int moves;

	private Board[] result;

	private Board initialBoard;

	private SolverIterable iterable;

	private class Node {
		public Board board;
		public Node pre;
		public Integer steps;

		public Node(Board board, Integer steps, Node pre) {
			this.board = board;
			this.steps = steps;
			this.pre = pre;
		}

	}

	private class StepComparator implements Comparator<Node> {
		@Override
		public int compare(Node o1, Node o2) {
			return (o1.steps - o2.steps) + (o1.board.manhattan() - o2.board.manhattan());
		}

	}

	public Solver(Board initial) {
		// find a solution to the initial board (using the A* algorithm)
		if (initial == null)
			throw new NullPointerException();
		this.initialBoard = initial;
//		Stopwatch s = new Stopwatch();
		int top = Math.max(initialBoard.manhattan(), initialBoard.twin().manhattan());
		init(top);
		moves = predict(queues, twinQueues);
		queues = null;
		twinQueues = null;
		// StdOut.println(s.elapsedTime());
	}

	private int predict(MinPQ<Node> queues, MinPQ<Node> twinQueues) {
		Node i = new Node(initialBoard, 0, null);
		queues.insert(i);
		Node ti = new Node(initialBoard.twin(), 0, null);
		twinQueues.insert(ti);
		while (true) {
			if (queues.min().board.isGoal()) {
				Node r = queues.min();
				result = new Board[r.steps + 1];
				int index = 0;
				while (r != null) {
					result[index] = r.board;
					index++;
					r = r.pre;
				}
				return queues.delMin().steps;
			} else if (twinQueues.min().board.isGoal()) {
				return -1;
			} else {
				processNode(queues);
				processNode(twinQueues);
			}
		}
		// return -1;
	}

	private void processNode(MinPQ<Node> queues) {
		Node search = queues.delMin();
		Board b = search.board;
		Iterator<Board> i = b.neighbors().iterator();
		while (i.hasNext()) {
			boolean duplicate = false;
			Board n = i.next();
			Node t = search;
			while (t != null) {
				if (n.equals(t.board))
					duplicate = true;
				t = t.pre;
			}
			if (!duplicate) {
				Node insertNode = new Node(n, search.steps + 1, search);
				queues.insert(insertNode);
			}
		}
	}

	public boolean isSolvable() {
		// is the initial board solvable?
		return moves != -1;

	}

	private void init(int top) {
		queues = new MinPQ<Node>(top, new StepComparator());
		twinQueues = new MinPQ<Node>(top, new StepComparator());
	}

	public int moves() {
		// min number of moves to solve initial board; -1 if unsolvable
		if (isSolvable())
			return moves;
		return -1;

	}

	public Iterable<Board> solution() {
		// sequence of boards in a shortest solution; null if unsolvable
		if (iterable == null)
			iterable = new SolverIterable();
		if (isSolvable())
			return iterable;
		return null;
	}

	private class SolverIterable implements Iterable<Board> {

		@Override
		public Iterator<Board> iterator() {

			return new Iterator<Board>() {
				int index = result.length - 1;

				@Override
				public boolean hasNext() {
					return index >= 0;
				}

				@Override
				public Board next() {
					return result[index--];
				}
			};
		}

	}

	public static void main(String[] args) {
		// solve a slider puzzle (given below)
		// create initial board from file
		In in = new In(args[0]);
		int n = in.readInt();
		int[][] blocks = new int[n][n];
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++)
				blocks[i][j] = in.readInt();
		Board initial = new Board(blocks);

		// solve the puzzle
		Solver solver = new Solver(initial);

		// print solution to standard output
		if (!solver.isSolvable())
			StdOut.println("No solution possible");
		else {
			StdOut.println("Minimum number of moves = " + solver.moves());
			for (Board board : solver.solution())
				StdOut.println(board);
		}
	}
}