import java.util.Comparator;
import java.util.Iterator;

import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.StdRandom;

public class Board {

	private int[][] blocks;
	private int[][] goalBlocks;
	private int n;

	private MinPQ<Board> queues;

	public Board(int[][] blocks) {
		// construct a board from an n-by-n array of blocks
		queues = new MinPQ<Board>(new Comparator<Board>() {

			@Override
			public int compare(Board o1, Board o2) {
				return o1.hamming() - o2.hamming();
			}

		});

		this.n = blocks.length;
		this.blocks = new int[n][n];
		goalBlocks = new int[n][n];
		for (int i = 0; i < n * n; i++) {
			this.blocks[i / n][i % n] = blocks[i / n][i % n];
		}

		for (int i = 0; i < n * n; i++) {
			if (i == n * n - 1)
				goalBlocks[i / n][i % n] = 0;
			else
				goalBlocks[i / n][i % n] = i + 1;
		}
		assert checkInit(blocks);
	}

	// (where blocks[i][j] = block in row i, column j)
	public int dimension() {
		// board dimension n
		return n;
	}

	public int hamming() {
		// number of blocks out of place
		int count = 0;
		for (int i = 0; i < n * n - 1; i++) {// do not count blank square
			if (goalBlocks[i / n][i % n] != blocks[i / n][i % n])
				count++;
		}
		return count;
	}

	public int manhattan() {
		// sum of Manhattan distances between blocks and goal
		int distance = 0;
		for (int i = 0; i < n * n - 1; i++) {// do not count blank square
			if (goalBlocks[i / n][i % n] != blocks[i / n][i % n]) {
				for (int j = 0; j < n * n; j++) {
					if (goalBlocks[i / n][i % n] != blocks[j / n][j % n]) {
						distance += (Math.abs(j / n - i / n) + Math.abs(j % n - i % n));
						break;
					}
				}
			}

		}
		return distance;
	}

	public boolean isGoal() {
		// is this board the goal board?
		for (int i = 0; i < n * n; i++) {
			if (goalBlocks[i / n][i % n] != blocks[i / n][i % n])
				return false;
		}
		return true;
	}

	public Board twin() {
		// a board that is obtained by exchanging any pair of blocks
		int i = 0;
		int j = 0;
		while (blocks[i / n][i % n] == 0 || blocks[j / n][j % n] == 0 || blocks[i / n][i % n] == blocks[j / n][j % n]) {
			i = StdRandom.uniform(n * n);
			j = StdRandom.uniform(n * n);
		}
		int[][] twinBlocks = new int[n][n];
		for (int num = 0; num < n * n; num++) {
			twinBlocks[num / n][num % n] = blocks[num / n][num % n];
		}

		int t = twinBlocks[i / n][i % n];
		twinBlocks[i / n][i % n] = twinBlocks[j / n][j % n];
		twinBlocks[j / n][j % n] = t;

		Board twin = new Board(twinBlocks);
		return twin;
	}

	public boolean equals(Object y) {
		// does this board equal y?
		Board that = (Board) y;
		return this.toString().equals(that.toString());
	}

	public Iterable<Board> neighbors() {
		// all neighboring boards
		int num = 0;
		for (int i = 0; i < n * n; i++) {
			if (blocks[i / n][i % n] == 0) {
				num = i;
				break;
			}
		}
		if (num / n > 0 && num / n < n) {
			int[][] nBlock = new int[n][n];
			for (int i = 0; i < n * n; i++) {
				nBlock[i / n][i % n] = blocks[i / n][i % n];
			}

			nBlock[num / n][num % n] = nBlock[num / n - 1][num % n];
			nBlock[num / n - 1][num % n] = 0;

			Board nBoard = new Board(nBlock);
			queues.insert(nBoard);
		}

		if (num / n < n - 1 && num / n >= 0) {
			int[][] nBlock = new int[n][n];
			for (int i = 0; i < n * n; i++) {
				nBlock[i / n][i % n] = blocks[i / n][i % n];
			}

			nBlock[num / n][num % n] = nBlock[num / n + 1][num % n];
			nBlock[num / n + 1][num % n] = 0;

			Board nBoard = new Board(nBlock);
			queues.insert(nBoard);
		}

		if (num % n > 0 && num % n < n) {
			int[][] nBlock = new int[n][n];
			for (int i = 0; i < n * n; i++) {
				nBlock[i / n][i % n] = blocks[i / n][i % n];
			}

			nBlock[num / n][num % n] = nBlock[num / n][num % n - 1];
			nBlock[num / n][num % n - 1] = 0;

			Board nBoard = new Board(nBlock);
			queues.insert(nBoard);
		}

		if (num % n < n - 1 && num % n >= 0) {
			int[][] nBlock = new int[n][n];
			for (int i = 0; i < n * n; i++) {
				nBlock[i / n][i % n] = blocks[i / n][i % n];
			}

			nBlock[num / n][num % n] = nBlock[num / n][num % n + 1];
			nBlock[num / n][num % n + 1] = 0;

			Board nBoard = new Board(nBlock);
			queues.insert(nBoard);
		}

		return new BoardIterable();
	}

	private class BoardIterable implements Iterable<Board> {

		@Override
		public Iterator<Board> iterator() {

			return new Iterator<Board>() {

				@Override
				public Board next() {
					return queues.delMin();
				}

				@Override
				public boolean hasNext() {
					return !queues.isEmpty();
				}

			};
		}

	}

	public String toString() {
		// string representation of this board (in the output format specified
		// below)
		String result = "";
		for (int i = 0; i < n * n; i++) {
			result += (" " + this.blocks[i / n][i % n]);
			if ((i + 1) % n == 0)
				result += "\n";
		}
		return result;
	}

	private boolean checkInit(int[][] blocks) {
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (this.blocks[i][j] != blocks[i][j])
					return false;
			}
		}
		for (int i = 0; i < n * n; i++) {
			if (i == n * n - 1) {
				if (goalBlocks[i / n][i % n] != 0)
					return false;
			} else if (goalBlocks[i / n][i % n] != i + 1)
				return false;
		}
		return true;
	}

	public static void main(String[] args) {
		// unit tests (not graded)
		Board b = new Board(new int[][] { { 3, 1 }, { 2, 0 } });
	}

}